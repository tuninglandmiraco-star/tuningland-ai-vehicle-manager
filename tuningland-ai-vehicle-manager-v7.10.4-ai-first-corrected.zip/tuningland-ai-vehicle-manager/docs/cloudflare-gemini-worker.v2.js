/**
 * Tuningland Gemini Research Worker v2
 *
 * Purpose:
 * - Keep GEMINI_API_KEY inside Cloudflare Worker Secrets.
 * - Provide a health endpoint for the WordPress plugin.
 * - Make Gemini the primary research provider.
 * - Let Gemini use Google Search grounding when it needs current/source-backed data.
 * - Return a stable JSON envelope that the Tuningland plugin can consume.
 *
 * Cloudflare Secret required:
 *   GEMINI_API_KEY
 *
 * Optional Cloudflare variable:
 *   GEMINI_MODEL = gemini-2.5-flash
 */

const ALLOWED_ORIGINS = [
  "https://www.tuningland.ir",
  "https://tuningland.ir",
];

const DEFAULT_MODEL = "gemini-2.5-flash";

export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin") || "";

    if (request.method === "OPTIONS") {
      return corsResponse("", 204, origin);
    }

    if (request.method !== "POST") {
      return jsonResponse({ success: false, error: "POST required" }, 405, origin);
    }

    try {
      const body = await request.json();
      const action = body.action || "research";

      if (action === "health") {
        return jsonResponse(await healthCheck(env), 200, origin);
      }

      if (action === "research") {
        const result = await research(body, env);
        return jsonResponse(result, result.success ? 200 : 502, origin);
      }

      return jsonResponse({
        success: false,
        error: "Unknown action. Use health or research."
      }, 400, origin);

    } catch (error) {
      return jsonResponse({
        success: false,
        error: error?.message || "Worker error"
      }, 500, origin);
    }
  },
};

async function research(body, env) {
  if (!env.GEMINI_API_KEY) {
    return {
      success: false,
      provider: "gemini",
      error: "GEMINI_API_KEY secret is missing"
    };
  }

  const model = body.model || env.GEMINI_MODEL || DEFAULT_MODEL;
  const vehicle = body.vehicle || {};
  const field = body.field || {};

  const fieldName =
    field.label || field.name || body.field_name || "Unknown field";

  const vehicleName =
    vehicle.name ||
    [vehicle.brand, vehicle.model, vehicle.year].filter(Boolean).join(" ") ||
    body.vehicle_name ||
    "Unknown vehicle";

  const question =
    body.question ||
    body.input ||
    `Find the exact ${fieldName} for ${vehicleName}.`;

  const instructions = body.instructions || "";

  const prompt = buildResearchPrompt({
    vehicle,
    vehicleName,
    field,
    fieldName,
    question,
    instructions,
  });

  const payload = {
    contents: [
      {
        role: "user",
        parts: [{ text: prompt }]
      }
    ],
    generationConfig: {
      temperature: 0,
      maxOutputTokens: Number(body.max_output_tokens || 1800),
      responseMimeType: "application/json"
    },
    // Gemini can decide when web grounding is useful. The search is executed
    // by Google's managed tool, not by WordPress.
    tools: [
      {
        googleSearch: {}
      }
    ]
  };

  const response = await callGemini(model, env.GEMINI_API_KEY, payload);
  const data = response.data;

  if (!response.ok) {
    // Some older/limited model configurations can reject JSON response mode
    // together with tools. Retry once without responseMimeType; the prompt
    // still requests JSON and the parser below validates it.
    if (payload.generationConfig && payload.generationConfig.responseMimeType) {
      const retryPayload = structuredClone(payload);
      delete retryPayload.generationConfig.responseMimeType;

      const retry = await callGemini(model, env.GEMINI_API_KEY, retryPayload);
      if (retry.ok) {
        return normalizeGeminiResponse(retry.data, model, vehicleName, fieldName);
      }
    }

    return {
      success: false,
      provider: "gemini",
      model,
      http_code: response.status,
      error: data?.error?.message || "Gemini request failed"
    };
  }

  return normalizeGeminiResponse(data, model, vehicleName, fieldName);
}

async function callGemini(model, apiKey, payload) {
  const url =
    "https://generativelanguage.googleapis.com/v1beta/models/" +
    encodeURIComponent(model) +
    ":generateContent?key=" +
    encodeURIComponent(apiKey);

  const started = Date.now();

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Accept": "application/json"
    },
    body: JSON.stringify(payload)
  });

  let data = null;
  try {
    data = await response.json();
  } catch (_) {
    data = { error: { message: "Invalid JSON response from Gemini" } };
  }

  return {
    ok: response.ok,
    status: response.status,
    data,
    latency_ms: Date.now() - started
  };
}

function normalizeGeminiResponse(data, model, vehicleName, fieldName) {
  let text = "";
  const parts = data?.candidates?.[0]?.content?.parts || [];

  for (const part of parts) {
    if (part?.text) text += part.text;
  }

  const clean = cleanJson(text);
  let result;

  try {
    result = JSON.parse(clean);
  } catch (_) {
    result = {
      found: false,
      value: null,
      unit: "",
      confidence: 0,
      field_type: "",
      reason: "Gemini did not return valid JSON.",
      sources: [],
      needs_web_research: true
    };
  }

  const grounding = data?.candidates?.[0]?.groundingMetadata || null;
  const sources = extractGroundingSources(grounding);

  // Merge Google grounding sources into the answer without trusting them as
  // the answer itself. The model must still have selected the value.
  if (!Array.isArray(result.sources)) result.sources = [];
  result.sources = dedupeSources([
    ...result.sources,
    ...sources
  ]);

  return {
    success: true,
    provider: "gemini",
    model,
    http_code: 200,
    latency_ms: null,
    vehicle: vehicleName,
    field: fieldName,
    result,
    grounding,
    // The WordPress client consumes `text` as the provider's model output.
    // Keep it equal to the structured result JSON, while the envelope also
    // exposes grounding/search metadata for the UI and audit trail.
    text: JSON.stringify(result),
    raw_text: text,
    // The plugin can use this to show that Gemini actually used Search.
    search_grounded: sources.length > 0 || !!grounding,
    sources
  };
}

function buildResearchPrompt({ vehicle, vehicleName, field, fieldName, question, instructions }) {
  return `
You are Tuningland's primary automotive research AI.

Your job is to answer ONE specific vehicle field with evidence. You are allowed to use Google Search grounding. When the answer requires current or source-specific information, SEARCH THE WEB before answering.

DO NOT GUESS.

VEHICLE:
${JSON.stringify(vehicle)}

VEHICLE NAME:
${vehicleName}

TARGET FIELD:
${fieldName}

FIELD SCHEMA:
${JSON.stringify(field)}

QUESTION:
${question}

ADDITIONAL APPLICATION INSTRUCTIONS:
${instructions}

AUTOMOTIVE SEMANTIC RULES:
1. Understand the exact meaning of the target field before extracting anything.
2. Engine oil viscosity is NOT engine oil capacity.
3. Engine oil is NOT transmission fluid.
4. Transmission fluid is NOT brake fluid.
5. Coolant is NOT engine displacement.
6. A number followed by L is NOT automatically the requested capacity.
7. Never use a vehicle model/name as a fluid specification.
8. Never use a viscosity value as a capacity.
9. Never use a capacity value as a viscosity.
10. For a transmission field, require transmission/gearbox context.
11. For an engine-oil field, require engine-oil context.
12. For coolant, require coolant/antifreeze context.
13. Prefer manufacturer or highly authoritative automotive sources.
14. If multiple reliable sources disagree, report the disagreement instead of guessing.
15. If evidence is insufficient, found must be false and value must be null.
16. If the ACF field is a select/enum field, only return one of the allowed choices supplied in FIELD SCHEMA.
17. Preserve the requested unit/format where the field schema specifies one.

SEARCH STRATEGY:
- Search for the exact vehicle and exact target specification.
- Prefer a page/section specifically about the target component or specification.
- Do not mix unrelated pages merely because they belong to the same vehicle.
- When a source page contains multiple capacities/specifications, use the label/context immediately associated with the value.
- Cite the strongest sources used.

RETURN JSON ONLY in this exact shape:
{
  "found": true,
  "value": "...",
  "unit": "...",
  "confidence": 0.0,
  "field_type": "...",
  "reason": "short evidence-based explanation",
  "sources": [
    {
      "title": "...",
      "url": "...",
      "evidence": "short quoted/paraphrased evidence"
    }
  ],
  "needs_web_research": false
}

If you cannot verify the value, return:
{
  "found": false,
  "value": null,
  "unit": "",
  "confidence": 0,
  "field_type": "...",
  "reason": "Why the evidence was insufficient",
  "sources": [],
  "needs_web_research": true
}
`;
}

function cleanJson(text) {
  return String(text || "")
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();
}

function extractGroundingSources(grounding) {
  const out = [];
  const chunks = grounding?.groundingChunks || [];

  for (const chunk of chunks) {
    const web = chunk?.web;
    if (!web?.uri) continue;
    out.push({
      title: web.title || web.uri,
      url: web.uri,
      evidence: "Google Search grounding source"
    });
  }

  return out;
}

function dedupeSources(sources) {
  const map = new Map();

  for (const source of sources || []) {
    if (!source || !source.url) continue;
    if (!map.has(source.url)) map.set(source.url, source);
  }

  return Array.from(map.values()).slice(0, 10);
}

async function healthCheck(env) {
  if (!env.GEMINI_API_KEY) {
    return {
      success: false,
      provider: "gemini",
      error: "GEMINI_API_KEY secret is not configured"
    };
  }

  const model = env.GEMINI_MODEL || DEFAULT_MODEL;
  const payload = {
    contents: [
      {
        role: "user",
        parts: [{ text: 'Reply with exactly {"status":"OK"}' }]
      }
    ],
    generationConfig: {
      temperature: 0,
      maxOutputTokens: 20,
      responseMimeType: "application/json"
    }
  };

  const response = await callGemini(model, env.GEMINI_API_KEY, payload);

  if (!response.ok) {
    return {
      success: false,
      provider: "gemini",
      model,
      http_code: response.status,
      error: response.data?.error?.message || "Gemini health check failed"
    };
  }

  return {
    success: true,
    provider: "gemini",
    model,
    http_code: response.status,
    latency_ms: response.latency_ms,
    message: "Gemini Worker is operational"
  };
}

function jsonResponse(body, status, origin) {
  return new Response(JSON.stringify(body), {
    status,
    headers: corsHeaders(origin)
  });
}

function corsResponse(body, status, origin) {
  return new Response(body, {
    status,
    headers: corsHeaders(origin)
  });
}

function corsHeaders(origin) {
  const allowed = ALLOWED_ORIGINS.includes(origin)
    ? origin
    : ALLOWED_ORIGINS[0];

  return {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": allowed,
    "Vary": "Origin",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization"
  };
}
